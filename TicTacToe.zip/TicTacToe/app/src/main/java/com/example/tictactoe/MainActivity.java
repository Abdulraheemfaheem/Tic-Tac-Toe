package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tictactoe.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button[] buttons = new Button[9];
    private TextView textViewStatus;

    private boolean player1Turn = true;
    private int roundCount = 0;
    private int[] board = new int[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewStatus = findViewById(R.id.text_view_status);

        for (int i = 0; i < 9; i++) {
            String buttonID = "button" + (i + 1);
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = findViewById(resID);
            buttons[i].setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int index = Integer.parseInt(((Button) v).getTag().toString()) - 1;
        if (board[index] != 0) {
            return;
        }

        board[index] = player1Turn ? 1 : 2;
        ((Button) v).setText(player1Turn ? "X" : "O");

        roundCount++;
        if (checkWin()) {
            playerWin();
        } else if (roundCount == 9) {
            draw();
        } else {
            player1Turn = !player1Turn;
            textViewStatus.setText("Player " + (player1Turn ? "1" : "2") + "'s Turn");
        }
    }

    private boolean checkWin() {
        // Check rows, columns, and diagonals for a win
        // Check rows, columns, and diagonals for a win
        int[][] winningPositions = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // rows
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // columns
                {0, 4, 8}, {2, 4, 6}             // diagonals
        };

        for (int[] winningPosition : winningPositions) {
            if (board[winningPosition[0]] == board[winningPosition[1]] &&
                    board[winningPosition[1]] == board[winningPosition[2]] &&
                    board[winningPosition[0]] != 0) {
                return true;
            }
        }
        return false;
    }

    private void playerWin() {
        Toast.makeText(this, "Player " + (player1Turn ? "1" : "2") + " wins!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void resetBoard() {
        for (int i = 0; i < 9; i++) {
            board[i] = 0;
            buttons[i].setText("");
        }

        roundCount = 0;
        player1Turn = true;
        textViewStatus.setText("Player 1's Turn");
    }
}
